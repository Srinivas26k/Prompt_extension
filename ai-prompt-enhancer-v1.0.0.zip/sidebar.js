// Sidebar script for AI Prompt Enhancer
console.log("Sidebar script loaded");

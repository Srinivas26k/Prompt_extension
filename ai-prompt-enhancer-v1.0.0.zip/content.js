// Content script for AI Prompt Enhancer
console.log("Content script loaded");
